<?php get_header();?>
    <!-- Menu Part End -->
    <!-- Hero Part start -->
    <?php get_template_part('template_part/content/hero')?>
    <!-- Hero Part End -->
    <!-- Photo Part Start -->
    <?php get_template_part('template_part/content/photo')?>
    <!-- Photo Part End -->
    <!-- News Part Start -->
    <section class="container news">
        <div class="row">
        <div class="col-sm-5">
                <?php dynamic_sidebar('newslineleft');?>
            </div>
            <div class="col-sm-2">
                <?php dynamic_sidebar('newstitle');?>
            </div>
            <div class="col-sm-5">
                <?php dynamic_sidebar('newslineright');?>
            </div>
        </div>
        <div class="row">

        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <?php 
        $qry = new WP_Query([
            'post_type'=> 'post',
            'category_name'=> 'slider'
        ]);
        ?>
  <div class="carousel-inner">
<?php
$x = 0;
while( $qry->have_posts()){$qry->the_post();
$x++;

?>

    <div class="carousel-item <?= ($x==1)? 'active':'' ?>">
        <?php the_title();?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php }?>

  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

        </div>
    </section>
    <!-- News Part End -->
    <!-- Footer Part start -->
    <?php get_footer();?>