<?php get_header();?>
<div class="container">
    <?php 
    while(have_posts()):the_post();
    ?>
<div class="text-center bg-info pt-5 pb-5">

<?php the_title('<h2 class="Tit">', '</h2>');?>
</div>
<div class="container">
    <?php the_content();?>
</div>

    <?php endwhile;?>
</div>

<?php get_footer();?>