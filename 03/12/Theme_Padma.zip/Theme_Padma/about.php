<?php 
/**
*Template Name: About
*/ 

get_header();?>
    <!-- Search Part Start -->
    <section class="container search">
        <div class="row">
            <div class="col-sm-8"></div>
            <div class="col-sm-4">
                <form action="">
                    <input type="text" value="<?= get_search_query();?>" name="s">
                    <button>Search</button>
                </form>
            </div>
        </div>
    </section>
    <!-- Search Part End -->
    <!-- Marque Part Start -->
    <section class="container marque">
        <marquee behavior="" direction="">
        <?php dynamic_sidebar('marque');?>
        </marquee>
    </section>
    <!-- Marque Part End -->
    
     
 

  <section class="container">
        <div class="row photo_top">
          <div class="col-sm-5">
          <?php dynamic_sidebar('photoimg1')?>
        </div>
        <div class="col-sm-2">
          <?php dynamic_sidebar('phototitle')?>
        </div>
        <div class="col-sm-5">
          <?php dynamic_sidebar('photoimg2')?>
        </div>
      </div>
</section>

<section class="container">
<?php
    $qry1 = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'padma'
    ]); 
    
    ?>
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
<?php $x = 0;
while ($qry1->have_posts()) {$qry1->the_post();
    $x++; ?>
    <div class="carousel-item <?= ($x==1)?'active':''?>">
        <?php the_title(); ?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php } ?>

     <!-- <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div> -->
  </div> 
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</section>

<?php get_footer();?>