<?php 
wp_enqueue_style('style-1',get_stylesheet_uri());
wp_enqueue_style('style-boot',get_template_directory_uri().'/Assets/css/bootstrap.min.css');

wp_enqueue_script( 'script-name', get_template_directory_uri() . '/Assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );
add_theme_support('custom-logo');
add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );


register_sidebar(array(
    'name'=>'Banner',
    'id'=>'banner',
    'before_widget'=>'',
    'after_widget'=>'',

));
register_sidebar(array(
    'name'=>'Side Images',
    'id'=>'sideimg',
    'before_widget'=>'',
    'after_widget'=>'',

));
register_sidebar(array(
    'name'=>'Side Video',
    'id'=>'sidevideo',
    'before_widget'=>'',
    'after_widget'=>'',

));
register_sidebar(array(
    'name'=>'Footer Image',
    'id'=>'footerimg',
    'before_widget'=>'',
    'after_widget'=>'',

));
register_sidebar(array(
    'name'=>'hero list',
    'id'=>'list',
    'before_widget'=>'',
    'after_widget'=>'',

));
?>
