<?php get_header();?>

<div class="container bg-info pt-5 pb-5 text-center">
<h1>404 Error! Page Not Found</h1>
</div>

<?php get_footer();?>