<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php wp_head();?>
</head>
<body>
    



    <!-- News Part Start -->
    <section class="container news">
        <div class="row">
        <div class="col-sm-5">
                <?php dynamic_sidebar('newslineleft');?>
            </div>
            <div class="col-sm-2">
                <?php dynamic_sidebar('newstitle');?>
            </div>
            <div class="col-sm-5">
                <?php dynamic_sidebar('newslineright');?>
            </div>
        </div>
        <div class="row">

        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <?php 
        $qry = new WP_Query([
            'post_type'=> 'post',
            'category_name'=> 'slider'
        ]);
        ?>
  <div class="carousel-inner">
<?php
$x = 0;
while( $qry->have_posts()){$qry->the_post();
$x++;

?>

    <div class="carousel-item <?= ($x==1)? 'active':'' ?>">
        <?php the_title();?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php }?>

  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

        </div>
    </section>
    <!-- News Part End -->
    <!-- Footer Part start -->
    <footer class="container-fluid footer">
        <section class="container">
            <div class="row ft">
                <div class="col-sm-6 fb_left">
                <?php dynamic_sidebar('footerleft');?>
                </div>
                <div class="col-sm-6 fb_right">
                <?php dynamic_sidebar('footerright');?>
                </div>
            </div>
            <div class="row footerbottom">
                <div class="col-sm-6 fb_left">
                <?php dynamic_sidebar('fbleft');?>
                </div>
                <div class="col-sm-6 fb_right">
                <?php dynamic_sidebar('fbright');?>
                </div>
            </div>
            </div>
        </section>
    </footer>
    <!-- Footer Part End -->


<?php wp_footer();?>
</body>
</html>