<?php get_header();?>

<div class="container bg-info pt-5 pb-5 text-center">
<h1>Under development</h1>
</div>

<?php get_footer();?>