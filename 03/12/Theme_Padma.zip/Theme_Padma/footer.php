<!-- Footer Part Start -->
<footer class="container-fluid footer bg-secondary">
  <div class="container">
  <div class="row ft_top">
    <div class="col-sm-6 footer_left mt-5">
    <?php dynamic_sidebar('footer_left')?>
    </div>
    <div class="col-sm-6 footer_right mt-5 ml-150">
    <?php dynamic_sidebar('footer_right')?>
    </div>
  </div>
  <div class="row ft_bottom bg-red">
  <?php dynamic_sidebar('footer_bottom')?>
  </div>
  </div>
</footer>

<!-- Footer Part End -->



<?php wp_footer();?>
</body>
</html>