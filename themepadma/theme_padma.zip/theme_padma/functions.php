<?php 
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-boot', get_template_directory_uri().'/assets/css/bootstrap.min.css ');
wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );








register_sidebar([
    'name'=>'News Line Left',
    'id'=>'newslineleft',
    'before_widget'  => '',
	'after_widget'   => '',
]);
register_sidebar([
    'name'=>'News Title',
    'id'=>'newstitle',
    'before_widget'  => '',
	'after_widget'   => '',
]);
register_sidebar([
    'name'=>'News Line Right ',
    'id'=>'newslineright',
    'before_widget'  => '',
	'after_widget'   => '',
]);
register_sidebar([
    'name'=>'Footer Left ',
    'id'=>'footerleft',
    'before_widget'  => '',
	'after_widget'   => '',
]);
register_sidebar([
    'name'=>'Footer Right ',
    'id'=>'footerright',
    'before_widget'  => '',
	'after_widget'   => '',
]);
register_sidebar([
    'name'=>'Footer Bottom Left',
    'id'=>'fbleft',
    'before_widget'  => '',
	'after_widget'   => '',
]);
register_sidebar([
    'name'=>'Footer Bottom Right',
    'id'=>'fbright',
    'before_widget'  => '',
	'after_widget'   => '',
]);



?>