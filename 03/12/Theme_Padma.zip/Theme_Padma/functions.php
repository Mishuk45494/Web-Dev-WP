<?php
wp_enqueue_style( 'style-1', get_stylesheet_uri() );
wp_enqueue_style( 'style-boot', get_template_directory_uri() . '/assets/css/bootstrap.min.css'  );
wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );
add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo', array(
    'height' => 480,
    'width'  => 720,
) );

add_theme_support( 'post-thumbnails' );
register_sidebar(array(
    'name'=>'Top Right Image',
    'id'=>'topimg',
    'before_widget'  => '',
		'after_widget'   => "",
));
register_nav_menus( array(
    'primary_menu' => __( 'Primary Menu', 'text_domain' ),
    'footer_menu'  => __( 'Footer Menu', 'text_domain' ),
) );

register_sidebar(array(
    'name'=>'Hero Title',
    'id'=>'herotitle',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Marque',
    'id'=>'marque',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Hero Card 1',
    'id'=>'card1',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));

register_sidebar(array(
    'name'=>'Photo Image left',
    'id'=>'photoimg1',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Photo Image right',
    'id'=>'photoimg2',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Photo Title',
    'id'=>'phototitle',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Photo Bottom Image 1',
    'id'=>'photobottomimg1',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Photo Bottom Image 2',
    'id'=>'photobottomimg2',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Photo Bottom Image 3',
    'id'=>'photobottomimg3',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Photo Bottom Image 4',
    'id'=>'photobottomimg4',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));



register_sidebar(array(
    'name'=>'Footer Left',
    'id'=>'footer_left',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Footer Right',
    'id'=>'footer_right',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'Footer Bottom',
    'id'=>'footer_bottom',
    'description'=>'',
    'class'=>'',
    'before_widget'  => '',
    'after_widget'   => "",
));

?>