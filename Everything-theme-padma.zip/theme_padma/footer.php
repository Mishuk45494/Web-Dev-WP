<footer class="container-fluid bg-secondary">
        <section class="container footer">
            <div class="row ft">
                <div class="col-sm-6 fb_left">
                <?php dynamic_sidebar('footerleft');?>
                </div>
                <div class="col-sm-6 fb_right">
                <?php dynamic_sidebar('footerright');?>
                </div>
            </div>
            <div class="row fb text-center">
            <div class="row">
                <div class="col-sm-6 fb_left">
                <?php dynamic_sidebar('fbleft');?>
                </div>
                <div class="col-sm-6 fb_right">
                <?php dynamic_sidebar('fbright');?>
                </div>
            </div>
            </div>
        </section>
    </footer>
    <!-- Footer Part End -->


<?php wp_footer();?>
</body>
</html>