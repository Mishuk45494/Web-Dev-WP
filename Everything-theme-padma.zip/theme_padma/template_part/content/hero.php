<section class="container hero text-center mt-5">
        <div class="row top">
            <?php dynamic_sidebar('herotitle')?>
        </div>
        <div class="row hero_bottom mt-5">
            <div class="col-sm-4">

            <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('card1');?>
            </div>
        </div>
            <div class="col-sm-4">
                <div class="card" style="width: 18rem;">
                    <?php dynamic_sidebar('card2');?>
                </div>      
             </div>
            <div class="col-sm-4">
                <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('card3');?>
                </div>
            </div>
        </div>
    </section>