// document.getElementById('demo').innerHTML='<h2>My Name Is Mishuk Sarker</h2>';
// document.getElementsByClassName('cls')[1].innerHTML='<h2>My Name Is Mishuk Sarker-2</h2>';
// document.getElementsByClassName('cls')[2].innerHTML='<h2>My Name Is Mishuk Sarker-3</h2>';
// document.querySelector('p').innerHTML='this a selector class p'
// JQuery
// tag
// $('p').text('this a selector class tag');
// id
// $('#demo').text('this a selector class id');

// document.querySelector('button').addEventListener('click',function(){
// document.querySelector('#demo').innerHTML='Mishuk sarker';
// });

// $('button').click(function(){
//     $('#demo').text('Mishuk Sarker Pritom');
// });


// $('button').mouseover(function(){
//     $('#demo').text('Mishuk Sarker Pritom');
// });


// $('button').on('mouseover',function(){
//     $('#demo').text('Mishuk Sarker Pritom');
// });
// Not Complete

$('.myButton').on('mouseover',function(){
    var value = this.innerHTML;
    $('h1').text(value + 'is clicked');
});
// Not Complete